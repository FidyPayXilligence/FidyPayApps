package com.fidypay.service;

public interface KycTypeListService {

}
