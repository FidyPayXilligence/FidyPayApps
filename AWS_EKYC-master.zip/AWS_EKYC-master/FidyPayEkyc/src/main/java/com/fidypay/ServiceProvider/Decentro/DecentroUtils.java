package com.fidypay.ServiceProvider.Decentro;

public class DecentroUtils {

	
	//----------------------------------Decentro APIS URLS UAT---------------------------------------------------	
//		public final static String DECENTRO_API_BASE_URL = "https://in.staging.decentro.tech/";
//		public final static String DECENTRO_CLIENT_ID = "fidypay_staging";
//		public final static String DECENTRO_CLIENT_SECRET = "dRr5IqBh5L4wQ2GYmst5iAxYLcWCLXEN";
//		public final static String DECENTRO_MODULE_SECRET = "OLD006mfTYAF4Zgco4rZkL0SkIPc6vtN";

	//----------------------------------Decentro APIS URLS LIVE---------------------------------------------------	
		public final static String DECENTRO_API_BASE_URL_UAT = "https://in.staging.decentro.tech/";
//		public final static String DECENTRO_CLIENT_ID = "FidyPay_prod";
//		public final static String DECENTRO_CLIENT_SECRET = "SyhDZLS2i5AyYbzUJQ4iszdUq4eDGGUs";
//		public final static String DECENTRO_MODULE_SECRET = "bbgOveF4EIxi8DlemqmL6bVfe7faEHzd";

		
	public final static String DECENTRO_API_BASE_URL = "https://in.decentro.tech/";
	public final static String DECENTRO_CLIENT_ID = "FidyPay_prod";
	public final static String DECENTRO_CLIENT_SECRET = "rb3etJpj9V9CxV8ezaPYqpQwVHZ021dv";
	public final static String DECENTRO_MODULE_SECRET = "rFSh0daYjWnLrdN3uPVMWq6ojA1ak39s";
	
	public final static String DECENTRO_CLIENT_ID_UAT = "fidypay_staging";
	public final static String DECENTRO_CLIENT_SECRET_UAT = "dRr5IqBh5L4wQ2GYmst5iAxYLcWCLXEN";
	public final static String DECENTRO_MODULE_SECRET_UAT = "OLD006mfTYAF4Zgco4rZkL0SkIPc6vtN";
}
