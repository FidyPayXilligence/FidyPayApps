package com.fidypay.request;

public class CKycRequest {

	private String ckycId;
	private String authFactor;

	public String getCkycId() {
		return ckycId;
	}

	public void setCkycId(String ckycId) {
		this.ckycId = ckycId;
	}

	public String getAuthFactor() {
		return authFactor;
	}

	public void setAuthFactor(String authFactor) {
		this.authFactor = authFactor;
	}

}
