package com.fidypay.dto;

public class RejectReasonPayload {

	private String rejectReason;

	public String getRejectReason() {
		return rejectReason;
	}

	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	
	
	
	
	
}
