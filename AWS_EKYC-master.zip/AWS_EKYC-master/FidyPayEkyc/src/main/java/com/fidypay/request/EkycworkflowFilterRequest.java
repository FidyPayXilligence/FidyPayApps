package com.fidypay.request;

public class EkycworkflowFilterRequest {

	
	private Long ekycWorkflowId;
	private String workflowUniqueId;
	
	public Long getEkycWorkflowId() {
		return ekycWorkflowId;
	}
	public void setEkycWorkflowId(Long ekycWorkflowId) {
		this.ekycWorkflowId = ekycWorkflowId;
	}
	public String getWorkflowUniqueId() {
		return workflowUniqueId;
	}
	public void setWorkflowUniqueId(String workflowUniqueId) {
		this.workflowUniqueId = workflowUniqueId;
	}
	
	
	
	
	
}
