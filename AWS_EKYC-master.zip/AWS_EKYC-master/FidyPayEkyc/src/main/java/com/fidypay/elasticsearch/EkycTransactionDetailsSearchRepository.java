//package com.fidypay.elasticsearch;
//
//import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
//
//import com.fidypay.entity.EkycTransactionDetails;
//public interface EkycTransactionDetailsSearchRepository extends ElasticsearchRepository<EkycTransactionDetails, Long>{
//
//}