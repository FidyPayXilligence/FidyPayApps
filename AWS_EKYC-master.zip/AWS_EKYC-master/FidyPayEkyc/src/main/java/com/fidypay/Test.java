package com.fidypay;

import java.util.HashMap;
import java.util.Map;

//
import org.json.JSONObject;

//
public class Test {

	public static void main(String[] args) {
//
////		int[] nums1 = { 3, 2, 2, 3 };
////
////		int val = 3;
////
////		int k = removeElementNew(nums1, val);
////
////		System.out.println(k);
//
		String apiResponse = "{\r\n"
				+ "    \"decentroTxnId\": \"078A81E28AF14103A1B89841124DE209\",\r\n"
				+ "    \"status\": \"FAILURE\",\r\n"
				+ "    \"responseCode\": \"S00000\",\r\n"
				+ "    \"message\": \"The email address was verified successfully.\",\r\n"
				+ "    \"data\": {\r\n"
				+ "        \"isDisposable\": false,\r\n"
				+ "        \"isPublic\": true,\r\n"
				+ "        \"account\": {\r\n"
				+ "            \"username\": \"yashvermafidypay\",\r\n"
				+ "            \"isGibberish\": false\r\n"
				+ "        }\r\n"
				+ "    },\r\n"
				+ "    \"responseKey\": \"success_public_email_found\"\r\n"
				+ "}";

		Map<String, Object> responseMap = new HashMap<>();
//
		JSONObject resultJsonObject = new JSONObject(apiResponse);

		String status = resultJsonObject.getString("status");
		String responseCode = resultJsonObject.getString("responseCode");

		if (status.equalsIgnoreCase("FAILURE") && responseCode.equalsIgnoreCase("S00000")) {

			JSONObject dataJson = resultJsonObject.getJSONObject("data");

//			responseMap = ekycCommonLogicConfig.buildResponse(ResponseMessage.SUCCESS,
//					ResponseMessage.API_STATUS_SUCCESS, ResponseMessage.DATA_FOUND);

			responseMap.put("DATA", dataJson.toMap());

			System.out.println(responseMap);

		} else {

			System.out.println("Response failed");

		}
//
//	}
//
//	public static int removeElementNew(int[] nums, int val) {
//		int index = 0;
//		for (int i = 0; i < nums.length; i++) {
//			if (nums[i] != val) {
//				nums[index] = nums[i];
//				index++;
//			}
//		}
//		return index;
//	}
//
//	private static int[] removeElement(int[] nums, int val) {
//
//		int count = 0;
//		int[] expected = new int[nums.length];
//		for (int i = 0; i < nums.length; i++) {
//			if (val == nums[i]) {
//
//				expected[count] = nums[i];
//				count++;
//			}
//		}
//		return expected;
//
	}
//
}
