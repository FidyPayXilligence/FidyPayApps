package com.fidypay.ServiceProvider.Karza;

public class KarzaUtils {

	//----------------------------------Karza APIS URLS UAT---------------------------------------------------	
		public final static String KARZA_API_BASE_URL = "https://testapi.karza.in/";
		public final static String KARZA_KEY = "NmXy370lZytA27VA";

		//----------------------------------Karza APIS URLS LIVE---------------------------------------------------	
//		public final static String KARZA_API_BASE_URL = "https://testapi.karza.in/";
//		public final static String KARZA_KEY = "NmXy370lZytA27VA";

	
}
