package com.fidypay.request;

public class ESignRequest {
	
	private String name;
	private String email;
	private String workflowId;
	//private String yob;
//	private String gender;
//	private String mobileNo;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}
	
	
	
	
	

}
