package com.fidypay.service;

public interface OCRServicesService {

	String kycOCR(String file, long parseLong, Double merchantFloatAmount);

}
